### First package
#### Get topic kafka voucher

- Get voucher code: VoucherTopic.GET_VOUCHER
